java -Djava.library.path=/usr/lib/jni -jar ezHomeController.jar
